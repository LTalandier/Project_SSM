# S0.4a phase 1 — build + pre-registered smoke: results (2026-07-07)

**Spec:** task_queue.md S0.4a (pre-registered at commit `0b8c817`, BEFORE this run).
**Gates: S1 ✅ · S2 ✅ (all gated methods, 3/3 seeds) · S3 ✅.** Raw: `results/s0_4a/smoke.json`;
rerun: `python3 analysis/s0_4a_smoke.py` (~2.5 min CPU, $0). Suite incl. gate tests: 138/138.

## Gate results

- **S1 (PAT correctness):** perfect-twin PAT gradient ≡ BPTT gradient to machine precision
  (cosine ≥ 1−1e−9, allclose rtol 1e−8) — `tests/test_s0_4a.py::test_S1...`.
- **S2 (trainability, C-1/N=8, 28 dB, 300 updates, seeds {11,23,47}):** every gated method cuts
  MSE ≥ 20 % on 3/3 seeds (gate needed 2/3):

| Method | final loss (mean-20, 3 seeds) | reduction | SER (held-out) | device passes | digital passes |
|---|---|---|---|---|---|
| BPTT (PR-3 reference) | 0.64–0.71 | 86–87 % | 0.21–0.24 | 0 | 4800 |
| PAT perfect | 0.64–0.71 | 86–87 % | 0.21–0.24 | 2400 | 4800 |
| PAT M-par | 0.69–0.75 | 85–86 % | 0.23–0.25 | 2400 | 4800 |
| PAT M-struct | 0.64–0.71 | 86–87 % | 0.21–0.24 | 2400 | 4800 |
| PAT both | 0.64–0.71 | 86–87 % | 0.21–0.24 | 2400 | 4800 |
| SPSA | 0.94–1.10 | 77–81 % | 0.33–0.39 | 4800 | 0 |
| head-only (context, ungated) | 1.18–1.23 | 75 % | 0.41 | 2400 | 0 |

- **S3 (PR-7 ledger):** SPSA 2×batch/update ✓ · PAT 1×batch physical + 2×batch digital ✓ ·
  BPTT 0 device ✓ (test-enforced).

## Findings (smoke-grade — S0.5 owns the gated claims)

1. **In-situ training beats readout-only already at N=8:** BPTT/PAT ≈ 0.67 vs head-only ≈ 1.20
   (SER 0.23 vs 0.41) — early, ungated evidence in the direction the debt-#1 falsifier needs.
2. **PAT absorbs the frozen mismatch levels almost completely at this scale:** PAT-both ≈
   BPTT to 3 digits; M-par is the binding family (≈ +6 % loss vs perfect); M-struct alone is
   free here. (Twin-mismatch sensitivity at C-2 + near the r_min boundary = the real test, S0.5.)
3. **SPSA trains** (77–81 % reduction) at ~2× the device passes and a higher floor within the
   same update budget — the sample-efficiency contrast the bake-off will quantify under PR-8.
4. **C-2/N=32 spot (100 updates, ungated): +4.7 % only, identical for BPTT/PAT/SPSA** — at the
   headline cell nothing has meaningfully started learning in 100 updates (head warm-up only).
   **Sizing flag for S0.5:** the C-2 budget B must be ≫ the C-1 smoke scale; method separation at
   C-2 is invisible at 100 updates.

## Registered smoke deviations (to re-freeze at S0.5 via PR-8/PR-6 §E)

Fixed lr (no cosine decay) · no HP search (single registered smoke HPs: lr_phys = 1e-3·κᵢ,
lr_head = 3e-2, SPSA c = 0.01·κᵢ) · c_readout fixed uniform · fixed encoder · SPSA one-sided
boundary handling not exercised (init far from bounds; clamp active) · N=8 taps = proportional
image {1,3,5,7} of the resolved B (the §B gate binds at C-2 only).
