# S0.4b — recurrent in-situ adjoint: build + pre-registered smoke (2026-07-07)

**Spec:** task_queue.md S0.4b (pre-registered at commit `c85fe62`, BEFORE this build/run).
**Gates: B1 ✅ · B2 ✅ (report-only, both cells meet the ≥0.9 expectation) · B3 ✅ (3/3 seeds) ·
B4 ✅ · B5 ✅.** Raw: `results/s0_4b/smoke.json`; rerun: `python3 analysis/s0_4b_smoke.py`
(~1 min CPU, $0). Suite incl. gate tests: 144/144.

## Registered simulation model (recap — full text in the spec)

Pass 1 = physical forward (fresh ASE tag `fwd`, no autograd; error computed digitally at the
measured y). Pass 2 = the physical adjoint pass, simulated as autodiff through a **fresh-ASE
replay of the device itself** (same commanded parameters — no twin, no PR-5 mismatch) with the
saturating gain **frozen at its operating-point value** (`detach_gain` — the counter-propagating
adjoint field sees the medium's saturation state; the ∂g/∂κ_ext self-consistency channel is
structurally absent from a physical adjoint). PR-7 row 3: **2×batch device passes/update,
digital = 0.** Registered limitations (both flattering — the adjoint arm is an **optimistic
bound**): ASE enters via the replay trajectory, not additively on the adjoint field
(error-launch power convention = unresolved hardware design, debt #4); non-reciprocity /
CW-CCW separability of a counter-propagating field = F8-ledger items.

## Gate results

- **B1 (structural floor — the roadmap S0.4 floor check):** fixed-gain plane, ASE off →
  adjoint gradient ≡ BPTT (cosine ≥ 1−1e−9, allclose rtol 1e−8) — test-enforced.
- **B2 (saturating-noiseless cosine at θ₀, report-only, expectation ≥ 0.9):**

| cell | cosine(adjoint, full BPTT) | expectation |
|---|---|---|
| C-1/N=8 | 0.9940 | meets |
| C-2/N=32 | 0.9247 | meets |

- **B3 (trainability, C-1/N=8, 28 dB, 300 updates, seeds {11,23,47}):** 3/3 seeds ≥ 20 % cut:

| seed | init → final loss | reduction | SER | device passes | digital |
|---|---|---|---|---|---|
| 11 | 4.821 → 0.674 | 86.0 % | 0.234 | 4800 | 0 |
| 23 | 4.914 → 0.647 | 86.8 % | 0.216 | 4800 | 0 |
| 47 | 4.922 → 0.715 | 85.5 % | 0.240 | 4800 | 0 |

- **B4 (PR-7 ledger):** 2×batch/update device, 0 digital — test-enforced.
- **B5 (value invariance):** `detach_gain=True` is bit-identical in forward values — test-enforced.
- **C-2/N=32 spot (100 updates, ungated):** +4.7 % — identical to BPTT/PAT/SPSA (the S0.4a
  sizing flag extends to adjoint).

## Findings (smoke-grade — S0.5 owns the gated claims)

1. **Adjoint trains at BPTT grade, at SPSA's device cost.** Final losses 0.647–0.715 vs BPTT
   0.640–0.708 and PAT 0.640–0.712 (same seeds), i.e. the fresh-ASE adjoint pass + dropped gain
   channel cost ≈1 % loss at this scale — but 4800 device passes vs PAT's 2400. The S0.5
   three-way tension is now concrete: PAT (1 pass + twin + digital ledger) vs adjoint (2 passes,
   no twin, optimistic-bound caveat + debt-#4 realizability) vs SPSA (2 passes, model-free,
   higher floor 0.94–1.10).
2. **The dropped ∂g/∂κ_ext channel GROWS with the cell: cosine 0.994 (C-1/N=8) → 0.925
   (C-2/N=32).** M-struct being "≈free" at C-1 smoke scale does NOT extrapolate; at the headline
   cell ~8 % of the gradient direction lives in the gain channel. Flag for S0.5: PAT M-struct
   and adjoint share this channel loss — their C-2 mismatch sensitivity must be measured, not
   assumed from C-1.
3. Smoke deviations identical to S0.4a's registered list (fixed lr, single registered HPs, fixed
   encoder / c_readout, proportional N=8 taps) — re-freeze at S0.5 via PR-8/PR-6 §E.
