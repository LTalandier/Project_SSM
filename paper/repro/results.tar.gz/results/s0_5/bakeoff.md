# S0.5-core — the gated 8-seed bake-off: RESULTS (2026-07-07)

**Governing registrations, all committed before the runs they govern:** PR-3/8/9 🔒 `ae16f6d` →
sizing addendum `7bcbcb9` → ceiling addendum `4fca58d` → runs. Raw: `results/s0_5/`
(`bakeoff.json`, `bakeoff_runs.json`, `ceiling.json`, `sizing.json`, per-unit `runs/*.json`).
Cell: **C-2/N=32 headline** (foundry P-AN800), T-A 4-PAM @ 28 dB, resolved B, frozen substrate.
**Budget B = 252,800 device passes** · target SER ≤ **0.00565** (= 1.25×ceiling + 0.005) ·
8 seeds {11,23,47,61,83,101,127,151}.

**Platform note (disclosed):** mixed-platform units — ceiling + 13 light units on the local
x86 workstation, the rest on Hetzner cpx51 (shared x86); same code, seeds, float64.

## Gates

| Gate | Rule (frozen) | Result |
|---|---|---|
| **ii-a (capacity)** | ceiling ≤ 0.5 × reservoir | **PASS ×21.5** — 0.00052 vs 0.0224 |
| **ii-b (trainability)** | PAT-both or SPSA ≥ 5/8 to target | **PASS — BOTH 8/8** |

## The ranked table (PR-8 lexicographic: success fraction → median passes; censored at B⁺)

| arm | success | median device passes to target | final SER (med) | digital ledger |
|---|---|---|---|---|
| **PAT-both** | **8/8** | **38,400** | 0.0008 | **505,600** (twin fwd+bwd) |
| **adjoint** | **8/8** | 73,600 | 0.0005 | 0 |
| **SPSA** | **8/8** | 176,000 | 0.0013 | 0 |
| **RHEL** | **0/8 (censored)** | — | **0.1409** | 0 |
| *head-only (baseline)* | 0/8 | — | 0.0224 | 0 |
| *offline-deploy (baseline)* | (8/8)* | (22,400)* | 0.0010 | 505,600 |

\* baseline, never ranked; its device passes are head-recal measurements only — the parameter
training was entirely digital.

Paired-by-seed bootstrap (10k), median-passes differences, 95 % CI:
PAT−SPSA = −137,600 [−155,200, −123,200] · adjoint−PAT = +35,200 [+35,200, +36,800] ·
adjoint−SPSA = −102,400 [−120,000, −88,000] · RHEL−anything ≈ +2.4M (censored sentinel).

## Verdicts (PR-9, mechanical)

1. **Gate ii passes decisively.** The Stage-0 trainability claim is in-data: **the recurrence-
   defining parameters {δ, κ_ext, μ} train to within the pre-registered margin of the exact-
   gradient ceiling on the physical(-simulated) substrate — by BOTH hardware-committed
   methods, 8/8 seeds.**
2. **No promotion.** Adjoint beats SPSA (−58 % passes, CI excludes 0) but LOSES to PAT-both on
   device passes (+92 %, CI excludes 0); promotion requires clearly-beating BOTH → not met.
   RHEL censored. **The hardware roadmap stays PAT/SPSA — the §5.2 guardrail outcome, now
   with data.** (F8 structural note pre-recorded: neither exotic could win criterion (b).)
3. **RHEL: F22 template B, sharpened at full budget** — final SER 0.1409 is **worse than
   readout-only** (+0.118 readout differential): under the honest echo sub-model at the
   registered cell the echo updates are actively harmful, not merely slow (attribution:
   dissipative-echo bias, per S0.4c; the C-1 idealized-C_op control tier re-run at full
   budget for the record). RHEL-on-SiN stays sim-only.
4. **M3: not triggered** (Δ_M3 = 0 — the gain-model class cannot flip any verdict; the
   PR-9 unit-inconsistency note stands, moot here).
5. **R3b readout differentials (the registered statement form):** PAT −0.0216 · adjoint
   −0.0219 · SPSA −0.0211 · offline −0.0214 · **RHEL +0.118** (all vs reservoir 0.0224).

## The honest headline finding beyond the gates (feeds §10 / S0.7)

**Offline-train-deploy is competitive at the frozen mismatch level.** With the same M-par
5 %-class calibration errors (F7.3 unification) and on-device head recalibration only, the
offline baseline reaches SER 0.0010 — statistically indistinguishable from in-situ PAT
(0.0008) at this cell/task. Both consume the same digital ledger (505,600). **At 5 %
calibration error, hardware-in-the-loop buys little over calibrate-then-deploy on this task**
— the in-situ case must therefore rest on (a) larger/unknown mismatch (PR-5 sensitivity rows,
S0.5-full), (b) drift over deployment time (not modeled at S0.5-core), and/or (c) the
envelope. The white-space claim (FIRST in-situ-trained recurrent photonic system) is a
demonstration claim and stands regardless; the ADVANTAGE-vs-offline claim is NOT yet in-data
and must be stated that way in the paper. This is precisely what the F7.3 fair-comparison
design was built to expose.

## Sample-efficiency story (the primary metric, in one line each)

- **PAT**: cheapest on the device (38,400 ≈ 4,800 sequence-updates) — but rides a 13×-larger
  digital ledger and the full twin-calibration burden (F8).
- **Adjoint**: BPTT-grade quality (final = ceiling exactly), zero digital, 1.9× PAT's device
  cost — and its pass is charged *as if* physically realizable (debt #4 caveat rides).
- **SPSA**: 4.6× PAT's device cost, zero digital, zero model, zero added hardware (F8
  simplest row) — the robustness/simplicity anchor of the Stage-1 plan.
- **RHEL**: censored; harmful at this cell under the honest echo.

## C-1 diagnostic tier (3 seeds {11,23,47}, full budget B; `bakeoff_diag_c1.json`)

C-1 ceiling = 0.0018, target = 0.0073. Isolates two mechanisms:

| arm | final SER (med) | reads |
|---|---|---|
| PAT-perfect | 0.0018 | = ceiling |
| PAT-M-par | 0.0018 | mismatch channel costs ≈0 **at C-1** |
| PAT-M-struct | 0.0018 | dropped-gain channel costs ≈0 **at C-1** |
| rhel-ideal | 0.0057 | **passes target with a PERFECT conjugator** |

1. **PAT absorbs both mismatch families at C-1** (all three ≡ ceiling). **Do NOT extrapolate to
   C-2:** the S0.4b B2 probe showed the ∂g/∂κ_ext (M-struct) channel grows to ~8 % of gradient
   direction at C-2 (cosine 0.925 vs 0.994 at C-1). The C-2 mismatch sensitivity is an
   S0.5-full row, not inferred from here — flagged.
2. **rhel-ideal reaches target at C-1 (0.0057 ≤ 0.0073) — the decisive control.** With
   η_c = 1 / no conjugation noise, RHEL's estimator mechanics DO train (consistent with R1's
   cosine → 1). Therefore RHEL's C-2 censored, worse-than-reservoir result is NOT broken
   mechanics — it is the **echo physics (dissipative bias) × cell**: fatal at the headline C-2
   (long memory, many decay lengths per echo), survivable at C-1. This is the R3a/R3b isolation
   design delivering exactly its intended attribution, now at full budget.

## Deviations / notes
- Registered simplifications unchanged (fixed encoder/c_readout, registered smoke HPs — the
  genuine HP-search tier and the loss/gain/ASE sweeps + PR-13/PR-14 remain S0.5-full items).
- Compute: ~4 h wall total across 20 local cores + 4 (then 3) Hetzner cpx51; ~€2 cloud.
