# S0.7-full-core — training-mode envelope (2026-07-08)

**Rules pre-registered at `bd37703`.** Inputs: S0.5 measured passes-to-target (8-seed medians) ·
PR-10 frozen per-sample conversion stack (lite rows, cited) · S0.4 method adders. N=32, 4-tap
drive, T=256 @ 2 GS/s (pass = 128 ns). Raw: `training_envelope.json`.

## Training energy to the PR-3 target (C-2)

| method | conversion energy OPT / CONS | digital compute | total (OPT corner) |
|---|---|---|---|
| PAT-both | 0.57 mJ / 21.6 mJ | **12.7–44 J** (1.27e13 FLOP twin ledger @ 1 TFLOPS/W–Brainwave class) | **~13–44 J (digital-dominated ×~10⁴)** |
| SPSA | 2.6 mJ / 99 mJ | 0 | **2.6 mJ** |
| adjoint | 1.1 mJ / 41 mJ | 0 | 1.1 mJ (+ realizability caveat) |
| RHEL | censored | 0 | per-update: pump 2.46 µJ = **42×** its OPT conversion stack |

## Findings

1. **The energy metric INVERTS the device-pass ranking.** PAT wins on device passes (38.4k) but
   its digital-twin ledger costs ~4–5 orders more energy than SPSA's entire training run. SPSA
   trains the recurrence to target for **~2.6 mJ all-in at the OPT corner** — the Stage-1
   training-energy story is SPSA's. The PR-7 §B rank-ledger principle ("no most-sample-efficient
   claim without both ledgers") anticipated exactly this; §7 must present both metrics side by side.
2. FLOP estimate is order-of-magnitude class (labelled); real accelerator utilization on a
   64-dim complex matvec would be far below peak → the true digital bill is likely WORSE —
   the direction strengthens the inversion.
3. RHEL's conjugator pump dominates its own conversion stack ×42 per update — the echo is
   energy-costly even before its accuracy failure (§5.4).
4. **Retrieval (the lite's case-threatening item) resolved FAVORABLY:** measured batch-1 RNN on
   edge GPUs delivers >100× below claimed peak (EdgeDRNN, arXiv:1912.12193 ⚠verify-page; Orin
   DLA falls back to GPU for LSTM/GRU class) → the Jetson-sustained comparisons stand with a
   citable deflator; Jetson-peak remains never-beaten and is reported as such.
5. The four lite exclusions (laser wall-plug, locking, control compute, packaging) remain
   unbudgeted (registered; only shrink positive cells) → named S0.8 retrieval list.
