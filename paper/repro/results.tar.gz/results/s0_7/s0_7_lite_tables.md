## Per-scenario photonic energy/sample [pJ] (rows: N; cols: GS/s)

### OPTxA  (conversion 37-41 pJ/sample; control 124 mW/ring x N)
| N | 0.1 GS/s | 1 GS/s | 2 GS/s |
|---|---|---|---|
| 8 | 9,957-9,961 | 1,029-1,033 | 533-537 |
| 32 | 39,717-39,721 | 4,005-4,009 | 2,021-2,025 |
| 128 | 158,757-158,761 | 15,909-15,913 | 7,973-7,977 |

### OPTxB  (conversion 37-41 pJ/sample; control 6 mW/ring x N)
| N | 0.1 GS/s | 1 GS/s | 2 GS/s |
|---|---|---|---|
| 8 | 517-521 | 85-89 | 61-65 |
| 32 | 1,957-1,961 | 229-233 | 133-137 |
| 128 | 7,717-7,721 | 805-809 | 421-425 |

### CONSxA  (conversion 788-798 pJ/sample; control 708 mW/ring x N)
| N | 0.1 GS/s | 1 GS/s | 2 GS/s |
|---|---|---|---|
| 8 | 57,428-57,438 | 6,452-6,462 | 3,620-3,630 |
| 32 | 227,348-227,358 | 23,444-23,454 | 12,116-12,126 |
| 128 | 907,028-907,038 | 91,412-91,422 | 46,100-46,110 |

### CONSxB  (conversion 788-798 pJ/sample; control 12 mW/ring x N)
| N | 0.1 GS/s | 1 GS/s | 2 GS/s |
|---|---|---|---|
| 8 | 1,748-1,758 | 884-894 | 836-846 |
| 32 | 4,628-4,638 | 1,172-1,182 | 980-990 |
| 128 | 16,148-16,158 | 2,324-2,334 | 1,556-1,566 |

## Baseline energy/sample [pJ] (per corner where the C6 ENOB mapping applies)

### OPT corner (DSP bits/sample = ENOB 9.4)
| N | Brainwave | Jetson-peak | Jetson-sustained | DSP-ASIC-class |
|---|---|---|---|---|
| 8 | 390 | 24 | 187 | 235-1,598 |
| 32 | 1,561 | 97 | 749 | 235-1,598 |
| 128 | 6,244 | 390 | 2,997 | 235-1,598 |

### CONS corner (DSP bits/sample = ENOB 8.4)
| N | Brainwave | Jetson-peak | Jetson-sustained | DSP-ASIC-class |
|---|---|---|---|---|
| 8 | 390 | 24 | 187 | 210-1,428 |
| 32 | 1,561 | 97 | 749 | 210-1,428 |
| 128 | 6,244 | 390 | 2,997 | 210-1,428 |

## Clearance matrix (photonic conservative high end vs baseline; CLEARS / LOSES / OVERLAP)

### OPTxA
| N @ GS/s | Brainwave | Jetson-peak | Jetson-sustained | DSP-ASIC-class |
|---|---|---|---|---|
| 8 @ 0.1 | LOSES | LOSES | LOSES | LOSES |
| 8 @ 1 | LOSES | LOSES | LOSES | OVERLAP |
| 8 @ 2 | LOSES | LOSES | LOSES | OVERLAP |
| 32 @ 0.1 | LOSES | LOSES | LOSES | LOSES |
| 32 @ 1 | LOSES | LOSES | LOSES | LOSES |
| 32 @ 2 | LOSES | LOSES | LOSES | LOSES |
| 128 @ 0.1 | LOSES | LOSES | LOSES | LOSES |
| 128 @ 1 | LOSES | LOSES | LOSES | LOSES |
| 128 @ 2 | LOSES | LOSES | LOSES | LOSES |

### OPTxB
| N @ GS/s | Brainwave | Jetson-peak | Jetson-sustained | DSP-ASIC-class |
|---|---|---|---|---|
| 8 @ 0.1 | LOSES | LOSES | LOSES | OVERLAP |
| 8 @ 1 | CLEARS | LOSES | CLEARS | CLEARS |
| 8 @ 2 | CLEARS | LOSES | CLEARS | CLEARS |
| 32 @ 0.1 | LOSES | LOSES | LOSES | LOSES |
| 32 @ 1 | CLEARS | LOSES | CLEARS | CLEARS |
| 32 @ 2 | CLEARS | LOSES | CLEARS | CLEARS |
| 128 @ 0.1 | LOSES | LOSES | LOSES | LOSES |
| 128 @ 1 | CLEARS | LOSES | CLEARS | OVERLAP |
| 128 @ 2 | CLEARS | LOSES | CLEARS | OVERLAP |

### CONSxA
| N @ GS/s | Brainwave | Jetson-peak | Jetson-sustained | DSP-ASIC-class |
|---|---|---|---|---|
| 8 @ 0.1 | LOSES | LOSES | LOSES | LOSES |
| 8 @ 1 | LOSES | LOSES | LOSES | LOSES |
| 8 @ 2 | LOSES | LOSES | LOSES | LOSES |
| 32 @ 0.1 | LOSES | LOSES | LOSES | LOSES |
| 32 @ 1 | LOSES | LOSES | LOSES | LOSES |
| 32 @ 2 | LOSES | LOSES | LOSES | LOSES |
| 128 @ 0.1 | LOSES | LOSES | LOSES | LOSES |
| 128 @ 1 | LOSES | LOSES | LOSES | LOSES |
| 128 @ 2 | LOSES | LOSES | LOSES | LOSES |

### CONSxB
| N @ GS/s | Brainwave | Jetson-peak | Jetson-sustained | DSP-ASIC-class |
|---|---|---|---|---|
| 8 @ 0.1 | LOSES | LOSES | LOSES | LOSES |
| 8 @ 1 | LOSES | LOSES | LOSES | OVERLAP |
| 8 @ 2 | LOSES | LOSES | LOSES | OVERLAP |
| 32 @ 0.1 | LOSES | LOSES | LOSES | LOSES |
| 32 @ 1 | CLEARS | LOSES | LOSES | OVERLAP |
| 32 @ 2 | CLEARS | LOSES | LOSES | OVERLAP |
| 128 @ 0.1 | LOSES | LOSES | LOSES | LOSES |
| 128 @ 1 | CLEARS | LOSES | CLEARS | LOSES |
| 128 @ 2 | CLEARS | LOSES | CLEARS | LOSES |

## Crossover rate vs Brainwave [GS/s] (photonic high end; inf = never)

| N | OPTxA | OPTxB | CONSxA | CONSxB |
|---|---|---|---|---|
| 8 | 2.84 | 0.14 | never | never |
| 32 | 2.61 | 0.13 | 29.71 | 0.50 |
| 128 | 2.56 | 0.12 | 16.64 | 0.28 |

## Section-10 clause: fires = False (16 OPT grid cells clear at least one baseline)

## Photonic per-sample latency LOWER BOUND [ns] vs Brainwave <4 ms

| GS/s | foundry corner (3.29 ns mem) | class-leading (49.4 ns mem) |
|---|---|---|
| 0.1 | 23.3 | 69.4 |
| 1 | 5.3 | 51.4 |
| 2 | 4.3 | 50.4 |

Brainwave batch-1 serving latency: <4 ms (author-stated) -> ratio ~1e5.

## Ring memory in samples at the line rate (T_mem x f_s)

| GS/s | foundry corner (3.29 ns) | class-leading (49.4 ns) |
|---|---|---|
| 0.1 | 0.33 | 4.9 |
| 1 | 3.29 | 49.4 |
| 2 | 6.58 | 98.8 |

## SPSA cadence floor (2 settles/iteration): class A: 0.08-0.22 ms; class B: 0.80-5.20 ms

Wrote JSON + 2 PNGs to /home/lucas/Documents/Project_SSM/results/s0_7
