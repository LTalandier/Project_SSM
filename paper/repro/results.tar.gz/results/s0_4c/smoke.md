# S0.4c — RHEL + honest χ³-FWM echo sub-model: build + pre-registered smoke (2026-07-07)

**Spec:** task_queue.md S0.4c (pre-registered at `5ca8d52`, BEFORE build/run; PR-11 numeric
freeze in-spec). **Gates: R1 ✅ · R2 ✅ · R3a ✅ (3/3, but see finding 1) · R4 ✅ · R5 ✅ ·
R3b report-only (see finding 1 — the registered template rule and the honest reading
disagree; both recorded).** Raw: `results/s0_4c/smoke.json`; rerun:
`python3 analysis/s0_4c_smoke.py` (~4 min CPU, $0). Suite incl. gate tests: 150/150.

## Gate results

- **R1 (dissipation-sequence floor check) ✅:** cosine(Δθ_RHEL, ∇θ truncated-BPTT), ideal
  C_op, ASE off:

| κ_net·T·dt | 1.021 | 0.340 | 0.146 | 0.034 |
|---|---|---|---|---|
| cosine | **−0.75** | +0.985 | +0.9987 | **+1.0000** |

  Monotone, ≥0.9 at the least-dissipative point — the theorem's non-dissipative limit is
  recovered exactly. **The −0.75 at high dissipation is itself load-bearing** (finding 2).
- **R2 ✅ (PR-11 invariant 4):** noisy-forward echo does not recover the noiseless state
  (O(1) recovery error ≫ ASE floor) — test-enforced.
- **PR-11 noise floors (registered "expect negligible — measure"):** conjugation quantum noise
  1.01 photons vs state 3.5–4.1e5 photons/mode → **2.5–2.9e-6 of state** (C-1/C-2). Confirmed
  negligible; η_c chain at θ₀ = **−22.4 dB** (η_ex²=0.735 × spiral −16.7 dB × timing e^(−1)),
  cell-independent (all-κᵢ-ratio chain).
- **R3a ✅ by the letter (idealized echo):** 3/3 seeds cut MSE 75.2–75.8 % → final loss
  1.194–1.197, SER 0.407–0.412.
- **R3b (honest frozen chain):** 1.193–1.201 / SER 0.407–0.414 — **identical to R3a within
  noise.**
- **R4 ✅:** 4×batch device passes/update (PR-7.1), digital 0 — test-enforced.
- **R5 ✅:** independent conjugation/ASE streams; undriven echo energy decays (no loss-sign
  flip) — test-enforced.
- **C-2 spot:** +4.5 %/100 updates — the S0.4a sizing flag extends to RHEL.

## Findings

1. **RHEL trains no better than readout-only at the registered cell — even with an IDEALIZED
   echo.** RHEL-ideal/RHEL-honest finals 1.19–1.20 / SER ≈ 0.41 ≡ the S0.4a **head-only
   plateau** (1.18–1.23 / 0.41); compare BPTT/PAT 0.64–0.71 (0.23), SPSA 0.94–1.10 (0.33–0.39)
   at the same budget. The 75 % cut that satisfies the R3a/R3b letter is the digital head's
   own learning. **The registered R3b→F22 rule (≥2/3 seeds cut ≥20 % → "template A") therefore
   mislabels the outcome**; the honest reading — in-situ contribution ≈ 0 vs the readout-only
   context arm — favors **template B**. Both recorded; the rule's gap (absolute cut vs
   readout-only differential) is exactly what the S0.5/PR-9 reservoir-baseline falsifier is
   designed to close — protocol note filed for the PR-9 freeze.
2. **The binding constraint is dissipative-echo bias, not the conjugation chain.** R3b ≡ R3a
   shows the −22.4 dB η_c chain is *not* what kills RHEL here. At the operating point
   (κ_net ≈ 0.7κᵢ, T = 256) the echo pass carries total decay κ_net·T·dt ≈ 27: the retraced
   state forgets the sequence after ~1/(κ_net·dt) ≈ 9 steps, so the ±ε trajectory difference
   carries gradient information for only the last few percent of the sequence — and the R1 row
   shows that at even κ_net·T·dt ≈ 1 the recovered direction is already ANTI-aligned (−0.75).
   RHEL's own validity condition (non-dissipative dynamics) is violated by ~27 decay lengths
   at the cell the recurrence needs. This is the §5.2 "odds-improved, not feasibility-
   reopened" conclusion, now in-data: the noise-axis improvement SiN buys is irrelevant
   because the *dissipation* axis is fatal at the operating point.
3. **The idealized-C_op control did its job** (the R3a/R3b design): it isolates the echo
   physics from the estimator mechanics — the mechanics are fine (R1 → 1.0000), the physics
   (dissipation) is the constraint. Template B's attribution menu resolves to
   "dissipative-echo bias" with the conjugation chain second-order at this cell.
4. Costs as registered: RHEL = 9600 device passes for 300 updates (4×batch, PR-7.1) — 2× SPSA,
   4× PAT — for head-only-grade accuracy at this cell.

## Registered deviations

Same smoke-scale list as S0.4a/b (fixed lr, single registered HPs, fixed encoder/c_readout,
proportional N=8 taps); ε_frac = 0.05 smoke value; equal-HP search at S0.5 (PR-8). The S0.5
bake-off runs RHEL under the same budget B as the others; these smoke numbers are ungated
context, not the Gate-ii verdict.
