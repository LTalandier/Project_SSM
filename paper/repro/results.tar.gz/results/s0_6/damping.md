# S0.6 — damping characterization (PR-12 R-ii; claim C7): RESULTS (2026-07-08)

**Spec pre-registered** in task_queue before the runs (commit `5a7f28b`). 96 units (2 arms ×
6 r-points × 8 seeds), C-2, BPTT reference, U_max = 12000, PR-3 §A eval protocol. Hetzner
3× cpx51 (~2.5 h, <€1, servers deleted); raw `results/s0_6/{runs/,damping.json}`.

## Curves (median SER over 8 seeds)

| r | pinned (κ_ext frozen; {δ,μ} train) | boxed [r_min, r] (full partition; R-ii) |
|---|---|---|
| 0.2 | 0.3931 | 0.4298 |
| 0.3 | 0.0384 † | 0.2867 † |
| 0.5 | 0.0085 † | 0.0116 † |
| 1.0 | 0.0021 (3/8 †) | 0.0016 (1/8 †) |
| **2.0** | **0.0013** (2/8 †) | **0.0005** |
| 3.0 | 0.0016 | **0.0005** |

† = non-plateaued at U_max (flagged per the registered rule; concentrated in the slow
mid-grid — every winning configuration plateaued, so the verdicts below rest on converged
points only).

## Verdicts (per the registered C7 rule)

1. **Damping is a first-order performance knob: ×302 spread** between plateaued endpoints
   (r = 0.2 → 0.393 vs r* = 2.0 → 0.0013, pinned). The task-optimal operating point is **deep
   overcoupling** (r* = 2.0, κ_net ≈ 4.1κᵢ, ≈5.5 samples of memory): T-A needs only the 7-tap
   span, and the *excess* memory of the light-damping regime (r = 0.2–0.3 → 30–45 samples) is
   actively harmful — interference outweighs recall. The D-LinOSS "damping is a free
   performance knob" thesis lands in-data, with the optimum on the heavily-damped side for
   this task class.
2. **R-ii CONFIRMED (the registered test):** every box whose span contains r* reaches within
   the margin (0.0066) of the best pinned point — [r_min, 2] and [r_min, 3] both reach
   **0.0005 = the S0.5 ceiling**, and in fact **beat the best uniform pin** (0.0013):
   per-ring trainable κ_ext finds a *heterogeneous* damping profile a uniform design point
   cannot express. Damping is a knob training absorbs — the designer must only ensure the
   feasible box *contains* the good regime, not pick the point.
3. **Coherence with S0.5:** the bake-off ran with the full box and reached 0.0005 — i.e., a
   large share of in-situ training's value on this task is *finding the damping operating
   point*. θ₀'s pinned value (r = 0.3 → 0.038) vs trained (0.0005) is a ×77 gap. This
   sharpens §5.5's offline-tie reading: offline training also finds r* on its (well-calibrated)
   model — the advantage question stays where §5.5 left it.
4. The S0.3-1 anomaly-B confound (fixed-budget conflating accuracy with speed) is handled by
   the plateau flags; the mid-grid censored points mean the ×302 spread is an U_max-bounded
   statement, but the R-ii verdict uses only plateaued configurations.
