# S0.4-0 calibration — results summary (2026-07-07)

**Task:** S0.4-0 items 1–4 (`task_queue.md`; item 5 = PR-5 recon is a separate memo,
`docs/s0_4/pr5_twin_mismatch_recon.md`). **Governing:** PR-6 v3 🔒 SIGNED 2026-07-07 (+PR-7/5/12),
PR-4 v2 §N/§G. **Mode:** single-session (Critic suspended 2026-07-07). **Cost:** $0, local, ~2 min.
**Raw data:** `results/s0_4_0/s0_4_0_calibration.json` (regenerate:
`python3 analysis/s0_4_0_calibration.py`; deterministic — noiseless, fixed seeds).

**Conventions (all registered):** C-2 headline (N=32), 2 GS/s, noiseless, splitting ON, gain
`saturating`, connected init μ_c=0.3κᵢ, on-resonance δ=0; task gradient = per-ring |∂L/∂δ_j| on a
T=200 registered-encoder 4-PAM drive, L = mean(y²) (test-h convention; MSE-to-target sensitivity row
co-measured); gate = every ring ≥ 10⁻³ (§B), K cap = 4, m_κ=0.05, Δr=0.02, δ-band [−κᵢ,+κᵢ].

## Item 1 — input map B: **RESOLVED = taps {3,12,21,30} (K=4); gate PASSES robustly; fallback (c) NOT triggered**

Two measurement-protocol rulings were needed (both recorded in the ledger addendum):
- **Gate reference.** The §B letter ("≥10⁻³·**ring-1's**") is gameable when ring 1 is not a tap: the
  reference itself is starved, and K=2 sets pass the letter with rings at ~10⁻⁵ of the max — the
  hollow-gate pathology the meaningful-ratio gate exists to kill. **Operative reading: reference =
  the max ring** (stricter-or-equal; both co-reported per candidate).
- **Drive-seed robustness.** Single-seed worst margins flicker ×20 with the drive realization
  (e.g. {6,17,27}: 1.89e-3 / 1.05e-4 / 1.36e-3), so a robustness protocol was adopted *before*
  evaluating finalists under it: per-ring ratio = **min over 5 fixed drive seeds** {7,19,41,101,271};
  the gate binds on the min.

Search trace (14 candidates; full table in JSON):

| Candidate (1-based) | K | single-seed ≥gate (vs max) | robust ≥gate (min-over-5) | robust worst ratio |
|---|---|---|---|---|
| {1} single-drive | 1 | 6/32 | — | (7.7e-26 = the capacity finding) |
| {8,24} / {9,25} / {7,23} | 2 | 22/32 | — | ~1e-5 |
| {6,17,27} best-K=3 | 3 | **32/32** | 24/32 | 1.05e-4 |
| {3,16,29} {2,16,30} {4,17,30} tail-covered | 3 | ≤31/32 | 18–20/32 | ≤3.1e-4 |
| **{1,9,17,25} REGISTERED SEED** | 4 | 30/32 | 28/32 | 1.24e-4 |
| {4,12,20,28} / {5,13,21,29} centered | 4 | 31/32 | — | ~1.1e-4 |
| {4,13,22,30} tail-covered | 4 | 32/32 | 31/32 | 7.2e-4 |
| **{3,12,21,30} tail-covered → RESOLVED** | 4 | **32/32** | **32/32** | **1.42e-3** |

- **The registered seed {1,9,17,25} is NOT the resolved B** — its geometry leaves ring 32 seven hops
  from the nearest tap (28/32 robust). Covering the tail (tap at 30) is what closes the gate. The
  seed did its registered job (search start), the search protocol ("then … completed coverage within
  K") found the winner. No K≤3 geometry clears robustly (best 24/32) ⇒ K=4 is minimal-within-cap on
  the evidence; K=2 fails under the honest reading regardless of seeds.
- **Participation profile under the resolved B** (settled |a_j|/max, constant P̄₀ drive): counts
  ≥{0.1, 10⁻², 10⁻³} = **{4, 26, 32}** of 32. Registered reporting rule: every "N=32" use carries
  this profile. Single-drive verification of the capacity finding: {1, 3, 5} (the Critic's ≈3/32,
  measured here on-resonance; their 3 was with the ±4κᵢ δ-band).
- Loss-robustness (seed set, MSE-to-target): 30/32 vs 30/32 — gate counts insensitive to the loss.
- **E/O cost to the S0.7 envelope (PR-10): 4 input channels** (4× DAC/modulator vs 1 — the §10
  conversion-overhead price of trainability; to be charged in S0.7-full).

## Item 2 — r_min (clause (a) alone): **r_min = 0.1606, cell-independent; M1 PASSED-check factor pinned — the ×37-vs-×91 debate is moot in-data**

| Cell | r\* (κ_net=0) | r_a (κ_net=0.05κᵢ) | **r_min = r_a+0.02** | κ_net/κᵢ at r_min |
|---|---|---|---|---|
| C-1 | 0.1336 | 0.1406 | **0.1606** | 0.1749 |
| C-2 | 0.1337 | 0.1406 | **0.1606** | 0.1749 |
| C-3 | 0.1337 | 0.1406 | **0.1606** | 0.1749 |

(Candidate ≈0.16 confirmed; the operative saturating-mode trainable band is **κ_ext/κᵢ ∈ [0.1606, 3]**,
now enforced by `clamp_to_bounds()`; K4 [0.1,3] retained as the passive/fixed-plane box. PR-12
init-consistency: κ_ext-init r₀=0.3 and the damping axis lie inside [0.1606, 3] ✓.)

**E_sym/E_sat record (the registered ×37-vs-×91 question):** the single-pole closed form predicts
×91.9 circulating build-up at the floor vs θ₀; the Critic's self-consistent solve predicted ×37. The
**measured as-built substrate gives ×0.42** (floor) and ×0.48 (r_min): the K-pol-3 doublet quenches
the on-resonance build-up at low κ_net (γ/κ_net = 16.6 at the floor ⇒ on-resonance reduction
1/(1+(γ/κ_net)²) ≈ 4×10⁻³) and chain hybridization (μ_c=0.3κᵢ ≫ κ_net) detunes the drive off the
split supermodes. Both prior estimates presumed a single on-resonance pole; neither materializes.
- E_sym/E_sat at the clause-(a) floor (as-built, measured): **[2.1×10⁻⁶, 3.8×10⁻⁵]** — *better* than
  the registered θ₀ band [5×10⁻⁶, 9×10⁻⁵].
- At r\* the as-built rollout has no steady state (κ_net→0; that is what the clamp exists for); the
  field-consistent solve gives ×0.95 ⇒ **[4.7×10⁻⁶, 8.5×10⁻⁵]**.
- Even the never-realized single-pole worst case (×91.9) keeps the ratio ≤ 8.3×10⁻³ ≪ O(1).
**Lucas's D-2026-06-13-1 check (registered PERFORMED+PASSED in §C v3) is hereby pinned with measured
factors — the M1 quasi-static margin at r\* and at the floor is as good as at the operating point.**

## Item 3 — §G-conformance check: **NOT conformance-cheap → on-resonance clamp stands; anchor-risk (vii) quantified (and material)**

Determination: implementing §G's P_circ = Σ|aⱼ|² on the actual field requires a per-episode
self-consistent solve (g ↔ field), which (a) changes the g(P̄) function all four estimators train
through (PR-6 §A fairness surface), (b) adds calibration passes that PR-7's cost unit would have to
price, and (c) qualitatively changes low-r stability. That is a model change, not an implementation
conformance fix — **anchor-risk (vii) stands** and the on-resonance clamp is operative.

Quantification (hypothetical δ-aware Lorentzian build-up, P̄(δ) ∝ 1/(κ_tot²+δ²), δ-band [−κᵢ,+κᵢ]):
at r_min, a ring detuned by |δ|=κᵢ de-saturates to **κ_net = −0.48κᵢ (super-threshold)**; a δ-aware
clause (a) would put r_min at **≈0.2547 (+0.094)**. The as-built substrate is δ-independent in g, so
the bake-off is self-consistent; the number above is the measured *model-limits* magnitude — it goes
to the paper's F19 limits section verbatim (a real device detuned at low κ_ext could lase where the
model does not).

## Item 4 — multi-tap E₀ (§G-addendum): **invariant; encoder scale unchanged**

CW-equivalent single-pole reading (δ=0, μ=0, γ=0, constant P̄₀, equal-amplitude split 1/√K):
E₀(measured) = 1.069×10⁸ photons for single-port, seed taps, and resolved B alike (ratio 1.000000 to
the frozen closed form 2κ_ext(P̄₀/ħω₀)/κ_net²). With equal *power* split over identical rings the
total settled energy is exactly the single-port E₀ — the §N formula stands over **total** energy with
**no numeric change**; the per-arm encoder scale is unchanged (scale = 1 at θ₀). The
"encoder-cannot-buy-SNR" invariant is preserved by construction.

## Code changes (freeze-conforming)

- `DissipativeRingSubstrate(input_taps=…)`: multi-tap input map B (equal amplitude split 1/√K);
  default `(0,)` bit-identical to the prior single-port convention.
- `clamp_to_bounds()`: saturating-mode operative lower bound = the measured r_min (0.1606,
  `cells.R_MIN_SATURATING`); fixed/passive modes keep K4 r=0.1. (Closes the standing
  "clamp projects to r=0.1, unsafe in saturating mode" known.)
- New tests: `tests/test_s0_4_0.py` (multi-tap default-identity + E₀ invariance + validation;
  mode-aware clamp).

## Consumes / feeds

Feeds: PR-6 §B/§C addendum (ledger) · S0.4a estimator builds (resolved B + operative clamp) ·
PR-10/S0.7 envelope (4 E/O channels) · PR-9 (falsifier margin context) · F19 limits (item 3 numbers).
The S0.4a bake-off must NOT re-tune B or r_min — both are frozen by the addendum.
