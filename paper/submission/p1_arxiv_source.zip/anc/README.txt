Supporting records for P1. Double underscores in filenames replace repository slashes.
The pre-registration ledger and literature dossiers are preserved verbatim.
The results archive contains historical invalid records as disclosed in notes N7/N8.
Code and full path layout: https://github.com/LTalandier/Project_SSM
